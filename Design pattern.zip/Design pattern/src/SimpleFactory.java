//简单工厂 利用里氏代换原则（父类可以接受子类的指针）在父类中判断类型并返回子类的指针 调用该实例化对象的方法会调用改子类的方法进行操作



public class SimpleFactory {

	public static void main(String[] args) {
//		calculationTypeFactory factory  = calculationTypeFactory.ReturnCalculationTypelass("-");
//		System.out.println(factory.operation(23, 53));
		
		calculationTypeFactory factory = calculationTypeFactory.ReturnCalculationTypelass("*");
		System.out.println(factory.operation(23, 43));
		
		
	}

}



/*
 * 
 * 接口类
 * interface CalculationOperationMethodProcotol{
	public String operation(int a,int b);
}

 * 
 * //第一种 利用接口进行简单工厂
class calculationTypeFactory implements CalculationOperationMethodProcotol{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return null;
	}
	static public calculationTypeFactory ReturnCalculationTypelass(String calculationType){
		calculationTypeFactory factory;
		switch (calculationType) {
		case "+":
			factory = new addCalculation();
			break;
		case "-":
			factory = new subCalculation();
			break;
		case "*":
			factory = new MulCalculation();
			break;
		default:
			factory = new DivCalculation();
			break;
		}
		return factory;
	}
}

class addCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a+b);
	}
}

class subCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a-b);
	}
}
class MulCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a*b);
	}
}
class DivCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		if (b == 0) {
			System.out.println("b不能为0");
			return "";
		}
		return String.valueOf(a/b);
	}
}
 * */


//第二种 利用抽象类进行操作
abstract class NewcalculationFactory{
	abstract public String operation(int a,int b);
}

class calculationTypeFactory extends NewcalculationFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return null;
	}
	static public calculationTypeFactory ReturnCalculationTypelass(String calculationType){
		calculationTypeFactory factory;
		switch (calculationType) {
		case "+":
			factory = new addCalculation();
			break;
		case "-":
			factory = new subCalculation();
			break;
		case "*":
			factory = new MulCalculation();
			break;
		default:
			factory = new DivCalculation();
			break;
		}
		return factory;
	}
}

class addCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a+b);
	}
}


class subCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a-b);
	}
}
class MulCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		// TODO Auto-generated method stub
		return String.valueOf(a*b);
	}
}
class DivCalculation extends calculationTypeFactory{
	@Override
	public String operation(int a, int b) {
		if (b == 0) {
			System.out.println("b不能为0");
			return "";
		}
		return String.valueOf(a/b);
	}
}




