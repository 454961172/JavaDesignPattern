//建造者模式 材料：先在父类定义好需要实现的方法。 分析需求去做子类不同的实现！ 建造者：生成的时候需要传入需求的子类（材料类型），然后调用方法建造的时候方法内部用这个需求
//的子类去调用所有方法。
/**
 定义：
    建造者模式：将一个负责对象的构建和它的表现分离，使得同样的构建过程可以创建不同的表示。
 
 要点：
    1、如果用了建造者模式，那么用户就只需要指定需要构造的类型就可以得到它们，而具体建造的过程和细节就不需知道了。
    2、构造者模式用于创建一些复杂的对象，这些对象内部构建间的建造顺序通常是稳定的，但对象内部的构建通常面临着复杂的变化。
 
 重要：
    构造者模式的好处就是使得建造代码与表示代码分离，由于建造者隐藏了该产品是如何组装的，所以若需要改变一个产品的内部表示，只需要再定制一个具体的构造者就可以了。
 
 适用：
    在创建复杂对象的算法应该独立于该对象的组成部分以及他们的组装配方时适用使用。
 */

public class BuilderPattern {

	public static void main(String[] args) {
		builderClass myBuilder = new builderClass(new ThirdBuilder());//只需要切换这个需求子类就可以有不同的效果
		myBuilder.create();
	}

}

//建造类
class builderClass {
	SuperBuilder myBuilder;
	public builderClass(SuperBuilder builder) {
		this.myBuilder = builder;
	}
	
	public void create() {
		this.myBuilder.addMethod();
		this.myBuilder.subMethod();
		this.myBuilder.DivMethod();
		this.myBuilder.MulMethod();
	}
	
}


//这些都是被建造类。 等同于零件
abstract class SuperBuilder{
	abstract void addMethod();
	abstract void subMethod();
	abstract void MulMethod();
	abstract void DivMethod();
}

class firstBuilder extends SuperBuilder{
	@Override
	void addMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是加法");
	}
	@Override
	void subMethod() {
		System.out.println("这是减法");
		
	}
	@Override
	void MulMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是乘法");
	}
	@Override
	void DivMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是除法");
	}
}

class SecondBuilder extends SuperBuilder{
	@Override
	void addMethod() {
		// TODO Auto-generated method stub
		System.out.println("这个类不会实现加法");
	}
	@Override
	void subMethod() {
		System.out.println("这是减法");
		
	}
	@Override
	void MulMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是乘法");
	}
	@Override
	void DivMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是除法");
	}
}

class ThirdBuilder extends SuperBuilder{
	@Override
	void addMethod() {
		// TODO Auto-generated method stub
		System.out.println("这个类不会实现加法");
	}
	@Override
	void subMethod() {
		System.out.println("这个类不会实现减法");
		
	}
	@Override
	void MulMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是乘法");
	}
	@Override
	void DivMethod() {
		// TODO Auto-generated method stub
		System.out.println("这是除法");
	}
}
