
public class Singleton {

	public static void main(String[] args) {
		
		
	}

}


//懒加载
final  class  SingletonMethod{
	
	private SingletonMethod() {};
	
	private static SingletonMethod share = null;
	public static  SingletonMethod getShare(){
		synchronized (SingletonMethod.class) {
			if (share == null) {
				share = new SingletonMethod();
			}
			return share;
		}
	}
	
}

//饿汉式单例类.在类初始化时，已经自行实例化   
final class Singleton1 {  
  private Singleton1() {}  
  private static final Singleton1 single = new Singleton1();  
  //静态工厂方法   
  public static Singleton1 getInstance() {  
      return single;  
  }  
}  
