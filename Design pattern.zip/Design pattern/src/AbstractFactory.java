

public class AbstractFactory {

	public static void main(String[] args) {
		supermarket shop = new huaRun();//只要切换类 就有不同的效果
		Phone WalmartShopPhone = shop.CreatePhone();
		WalmartShopPhone.LogPhone();
	}

}



//超市类 父类
abstract class supermarket{
	abstract public TV CreateTV();
	abstract public Phone CreatePhone();
}

//沃尔玛
class WalMart extends supermarket{
	public WalMart() {
		System.out.println("欢迎来到沃尔玛");
	}
	@Override
	public TV CreateTV() {
		TV tv = new WalmartTV();
		return tv;
	}
	@Override
	public Phone CreatePhone() {
		Phone phone = new WalmartPhone();
		return phone;
	}
}

//华润
class huaRun extends supermarket{
	public huaRun() {
		System.out.println("欢迎来到华润万家");
	}
	@Override
	public Phone CreatePhone() {
		Phone phone = new HuaRunPhone();
		return phone;
	}
	@Override
	public TV CreateTV() {
		TV tv = new HuaRunTV();
		return tv;
	}
}

//手机类
abstract class Phone {
	abstract void LogPhone();
}


//tv类
abstract class TV{
	abstract void LogTV();
}



//沃尔玛的产品
class WalmartPhone extends Phone{
	
	public WalmartPhone() {
		System.out.println("这是沃尔玛卖的手机");
	}
	
	@Override
	void LogPhone() {
		System.out.println("卖出了一部");
		
	}
}

class WalmartTV extends TV{
	public WalmartTV() {
		System.out.println("这是沃尔玛的tv");
	}
	@Override
	void LogTV() {
		// TODO Auto-generated method stub
		
	}
}
//华润万家的产品
class HuaRunPhone extends Phone{
	public HuaRunPhone() {
		// TODO Auto-generated constructor stub
		System.out.println("这是华润万家卖的手机");
	}
	@Override
	void LogPhone() {
		// TODO Auto-generated method stub
		
	}
}

class HuaRunTV extends TV{
	public HuaRunTV() {
		System.out.println("这是华润万家卖的tv");
	}
	@Override
	void LogTV() {
		// TODO Auto-generated method stub
		
	}
}


