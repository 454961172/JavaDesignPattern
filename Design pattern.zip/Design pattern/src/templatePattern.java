//模板模式  抽象相同的代码到父类 把不同的代码写在子类 方便切换 拓展。 当子类没有实现父类方法的时候 调用父类方法会进去myOperation，里面的This实际上是子类指针 调用
//SubOperation方法又回到子类去执行
/**
 模版方法模式：定义一个操作中的算法的骨架，而将一些步骤延迟到子类中。模版方法使得子类可以不改变一个算法的结构即可重定义该算法的某些特定步骤。
 
 模板方法模式效果与适用场景
 模板方法模式是基于继承的代码复用技术，它体现了面向对象的诸多重要思想，是一种使用较为频繁的模式。模板方法模式广泛应用于框架设计中，以确保通过父类来控制处理流程的逻辑顺序（如框架的初始化，测试流程的设置等）。
 
 5.1 模式优点
 模板方法模式的主要优点如下：
 (1) 在父类中形式化地定义一个算法，而由它的子类来实现细节的处理，在子类实现详细的处理算法时并不会改变算法中步骤的执行次序。
 (2) 模板方法模式是一种代码复用技术，它在类库设计中尤为重要，它提取了类库中的公共行为，将公共行为放在父类中，而通过其子类来实现不同的行为，它鼓励我们恰当使用继承来实现代码复用。
 (3) 可实现一种反向控制结构，通过子类覆盖父类的钩子方法来决定某一特定步骤是否需要执行。
 (4) 在模板方法模式中可以通过子类来覆盖父类的基本方法，不同的子类可以提供基本方法的不同实现，更换和增加新的子类很方便，符合单一职责原则和开闭原则。
 
 5.2 模式缺点
 模板方法模式的主要缺点如下：
 需要为每一个基本方法的不同实现提供一个子类，如果父类中可变的基本方法太多，将会导致类的个数增加，系统更加庞大，设计也更加抽象，此时，可结合桥接模式来进行设计。
 
 5.3 模式适用场景
 在以下情况下可以考虑使用模板方法模式：
 (1) 对一些复杂的算法进行分割，将其算法中固定不变的部分设计为模板方法和父类具体方法，而一些可以改变的细节由其子类来实现。即：一次性实现一个算法的不变部分，并将可变的行为留给子类来实现。
 (2) 各子类中公共的行为应被提取出来并集中到一个公共父类中以避免代码重复。
 (3) 需要通过子类来决定父类算法中某个步骤是否执行，实现子类对父类的反向控制。
 */

public class templatePattern {

	public static void main(String[] args) {
		templatePatternClass myClass = new differenceclass();
		myClass.myOperation();

	}

}

abstract class templatePatternClass{
	abstract public void SubOperation();
	public void myOperation() {
		System.out.println("这是我的操作，封装相同类型的代码");
		this.SubOperation();
	}
}

class SubClass extends templatePatternClass{
	@Override
	public void SubOperation() {
		System.out.println("这个是不同于其它类的代码 但是也会执行父类代码");
		
	}
}

class differenceclass extends templatePatternClass{
	@Override
	public void SubOperation() {
		// TODO Auto-generated method stub
		System.out.println("这个是不同于SubClass的代码 但是也会执行父类代码");
	}
}
